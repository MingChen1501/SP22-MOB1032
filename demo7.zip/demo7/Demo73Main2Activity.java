package com.example.mob103.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mob103.R;
public class Demo73Main2Activity extends AppCompatActivity {
    EditText txtU,txtP;
    Button btnLogin,btnCancel;
    CheckBox chk;
    String strU,strP;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo73_main2);
        txtU = findViewById(R.id.demo73TxtU);
        txtP = findViewById(R.id.demo73TxtP);
        btnLogin = findViewById(R.id.demo73Login);
        btnCancel = findViewById(R.id.demo73Cancel);
        chk = findViewById(R.id.demo73Check);
        textView = findViewById(R.id.demo73Tv);
        restorePreference();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
    public void login()
    {
        strU = txtU.getText().toString();
        strP = txtP.getText().toString();
        if(strU.isEmpty()||strP.isEmpty())
        {
            textView.setText("User,Pass khong de trong");
            return;
        }
        if(strU.equalsIgnoreCase("admin)")&&strP.equalsIgnoreCase("admin"))
        {
            savePass(strU,strP,chk.isChecked());//luu password
            textView.setText("Dang nhap thanh cong");
            Toast.makeText(getApplicationContext(),"Dang nhap thanh cong",Toast.LENGTH_LONG).show();
            //finish();
        }
    }
    public void savePass(String u,String p,boolean status) {
        SharedPreferences sharedPreferences
                = getSharedPreferences("HUNG_FILE", MODE_PRIVATE);//chuan bi file
        SharedPreferences.Editor editor = sharedPreferences.edit();//bat che do edit
        if (!status)
        {
            //xoa trang thai truoc do
            editor.clear();
        } else
        {
            //luu tru du lieu
            editor.putString("USERNAME",u);
            editor.putString("PASSWORD",p);
            editor.putBoolean("REMEMBER",status);
        }
        //luu lai toan bo
        editor.commit();
    }
    private void restorePreference()
    {
        SharedPreferences sharedPreferences
                = getSharedPreferences("HUNG_FILE", MODE_PRIVATE);
        boolean check = sharedPreferences.getBoolean("REMEMBER",false);
        if(check)
        {
            String u = sharedPreferences.getString("USERNAME","");
            txtU.setText(u);
            String p = sharedPreferences.getString("PASSWORD","");
            txtP.setText(p);
        }
        chk.setChecked(check);
    }

}
