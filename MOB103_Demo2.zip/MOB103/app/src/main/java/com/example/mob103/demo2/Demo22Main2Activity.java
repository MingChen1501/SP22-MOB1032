package com.example.mob103.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.mob103.R;

public class Demo22Main2Activity extends AppCompatActivity {
    //1.Khai bao cac bien
    EditText txt1,txt2;
    Button btn1,btn2;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main2);
        //2. Anh xa
        btn1 = findViewById(R.id.demo22Btn1);//anh xa tu XML sang Java
        txt1 = findViewById(R.id.demo22Txt1);
        txt2 = findViewById(R.id.demo22Txt2);
        tv1 = findViewById(R.id.demo22Tv1);
        btn2 = findViewById(R.id.demo22Btn2);
        //3. Xu ly su kien khi click button
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //5. goi ham tinhtong
                tinhtong();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Demo22Main2Activity.this,Demo23Main2Activity.class);

                intent.putExtra("so_a",txt1.getText().toString());
                intent.putExtra("so_b",txt2.getText().toString());
                startActivity(intent);
            }
        });
    }
    //4. Dinh nghia ham tinh tong
    public void tinhtong()
    {
        //4.1 lay text nhap vao o 1 va o 2: getText
        double a = Double.parseDouble(txt1.getText().toString());
        double b = Double.parseDouble(txt2.getText().toString());
        //4.2. Tinh toan
        double c = a+b;
        //4.3. Dua ket qua len man hinh
        tv1.setText("Tong la: "+String.valueOf(c)+"; Hieu la: "+String.valueOf(a-b));
    }
}
