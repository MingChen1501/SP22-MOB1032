package com.example.mob103.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mob103.R;
public class Demo23Main2Activity extends AppCompatActivity {
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo23_main2);
        tvKQ = findViewById(R.id.demo23TvKQ);
        //4.Lay du lieu duoc truyen den
        Intent intent1 = getIntent();//lay intent duoc chuyen sang
        String str_so_a = intent1.getExtras().getString("so_a");
        String str_so_b = intent1.getExtras().getString("so_b");
        //5.chuyen sang kieu float va tinh toan
        double tong = Double.parseDouble(str_so_a)+Double.parseDouble(str_so_b);
        double hieu = Double.parseDouble(str_so_a)-Double.parseDouble(str_so_b);
        //6. Dua ket qua len man hinh 2
        String kq = "Tong: "+tong+"; Hieu: "+hieu;
        tvKQ.setText(String.valueOf(kq));

    }
}
