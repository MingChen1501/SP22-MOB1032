package com.example.mob103.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.mob103.R;

public class Demo32Main2Activity extends AppCompatActivity {
    EditText txtA,txtB,txtC;
    Button btn;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        txtA = findViewById(R.id.demo32Txta);
        txtB = findViewById(R.id.demo32Txtb);
        txtC = findViewById(R.id.demo32Txtc);
        btn = findViewById(R.id.demo32Btn);
        intent = new Intent(Demo32Main2Activity.this,Demo32SecondMain2Activity.class);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gptb2();
            }
        });
    }
    public void gptb2()
    {
        intent.putExtra("hsa",txtA.getText().toString());
        intent.putExtra("hsb",txtB.getText().toString());
        intent.putExtra("hsc",txtC.getText().toString());
        startActivity(intent);
    }
}
