package com.example.mob103;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView txtLab11;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//lien kết với giao diện
        txtLab11 = findViewById(R.id.txtLab11);//Ánh xạ từ XML vào Java
        //Khai bao bien
        String masv = "PH0001";
        String tenSV = "Nguyen Van An";
        String lop = "CP17212";
        String hienthi = masv + ": "+tenSV+" : "+lop;//noi chuoi
        //Hien thi
        Toast.makeText(this,hienthi,Toast.LENGTH_LONG).show();
        //Toast.makeText(nơi hiển thị,nộidung,thời gian hiển thị).show();
        txtLab11.setText(hienthi);//đưa text lên điều khiển TextView

    }
}
