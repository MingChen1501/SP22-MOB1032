package com.example.mob103.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.mob103.R;

public class Demo33Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo33_main2);
        listView = findViewById(R.id.demo33listview);
        getDataToListview();
    }
    public void getDataToListview()
    {
        //1. Tạo mảng nguồn dữ liệu
        String[] arr = new String[]{
                "Lap trinh Java 1",
                "Lap trinh java 2",
                "Lap trinh javascript",
                "Lap trinh android co ban",
                "Lap trinh android nang cao"
        };
        //2. tryền dữ liệu từ mảng vào Adapter
        ArrayAdapter<String> adapter=
                new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arr);
        //3. đổ dữ liệu từ adapter lên listview
        listView.setAdapter(adapter);
    }
}
