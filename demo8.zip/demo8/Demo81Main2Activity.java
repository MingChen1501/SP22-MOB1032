package com.example.mob103.demo8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import com.example.mob103.R;
public class Demo81Main2Activity extends AppCompatActivity {
    WebView webView;
    Button button;
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo81_main2);
        webView = findViewById(R.id.demo81Webview);
        button = findViewById(R.id.demo81Btn);
        editText = findViewById(R.id.demo81Txt);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                load(editText.getText().toString());
            }
        });

    }
    public void load(String str)
    {
        webView.loadUrl(str);
        webView.setWebViewClient(new WebViewClient());
    }
}
