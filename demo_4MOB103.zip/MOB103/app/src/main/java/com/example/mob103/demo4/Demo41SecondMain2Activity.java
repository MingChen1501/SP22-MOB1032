package com.example.mob103.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mob103.R;

public class Demo41SecondMain2Activity extends AppCompatActivity {
    TextView tvResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_second_main2);
        tvResult = findViewById(R.id.demo41TvResult);
        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("mybundle");
        int a = bundle.getInt("so1");
        int b = bundle.getInt("so2");
        int us = uscln(a,b);
        int bs = bscnn(a,b);
        String kq = "USCLN: "+us+"; va BSCNN: "+bs;
        tvResult.setText(String.valueOf(kq));
    }
    //bscnn = (a*b)/uscln
    int uscln(int a, int b)
    {
        if(b==0) return a;
        return uscln(b,a%b);
    }
    int bscnn(int a,int b)
    {
        return (a*b)/uscln(a,b);
    }
}
