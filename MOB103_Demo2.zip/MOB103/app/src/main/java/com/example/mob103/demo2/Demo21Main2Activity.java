package com.example.mob103.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.mob103.R;

public class Demo21Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main2);
    }

    @Override
    protected void onStart() {
        Log.d("onStart","Ham onStart duoc goi");
        super.onStart();
    }

    @Override
    protected void onRestart() {
        Log.d("onRestart","Ham onRestart duoc goi");
        super.onRestart();
    }

    @Override
    protected void onResume() {
        Log.d("onResume","Ham onResume duoc goi");
        super.onResume();
    }

    @Override
    protected void onPause() {
        Log.d("onPause","Ham onPause duoc goi");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d("onStop","Ham onStop duoc goi");
        super.onStop();
    }
}
