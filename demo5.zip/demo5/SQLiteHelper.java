package com.example.mob103.demo5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {
    public static final String DBNAME="QLBH";
    public static final int VERSION = 1;
    public static final String CREATE_TABLE_PROD = "create TABLE PRODUCT (\n" +
            "\tid TEXT PRIMARY key,\n" +
            "  \tname TEXT,\n" +
            "  \tprice real,\n" +
            "  \timage real\n" +
            ");";
    public SQLiteHelper(Context context) {
        super(context, DBNAME, null, VERSION);//ham tao csdl
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_PROD);//tao bang product
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS PRODUCT;");//ham xoa cu, tao moi
    }
}
