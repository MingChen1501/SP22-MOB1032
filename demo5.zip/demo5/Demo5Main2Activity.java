package com.example.mob103.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ListView;

import com.example.mob103.R;

import java.util.ArrayList;
import java.util.List;

public class Demo5Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo5_main2);
        listView = findViewById(R.id.demo5listview);
        List<Product> products = new ArrayList<>();
        products.add(new Product("1","SP1",111, Color.RED));
        products.add(new Product("2","SP2",222, Color.GREEN));
        products.add(new Product("3","SP3",333, Color.BLUE));
        products.add(new Product("4","SP4",444, Color.CYAN));
        products.add(new Product("5","SP5",555, Color.DKGRAY));

        SQLiteHelper sqLiteHelper = new SQLiteHelper(this);
        CustomeAdapter adapter = new CustomeAdapter(this,R.layout.item_listview_demo5,products);
        listView.setAdapter(adapter);


    }
}
