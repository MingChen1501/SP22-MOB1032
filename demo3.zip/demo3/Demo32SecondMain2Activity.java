package com.example.mob103.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mob103.R;

public class Demo32SecondMain2Activity extends AppCompatActivity {
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_second_main2);
        tvKQ = findViewById(R.id.demo23TvKQ);
        Intent intent = getIntent();
        int a = Integer.parseInt(intent.getExtras().getString("hsa"));
        int b = Integer.parseInt(intent.getExtras().getString("hsb"));
        int c = Integer.parseInt(intent.getExtras().getString("hsc"));
        double delta = b*b-4*a*c;
        if(delta<0)
        {
            tvKQ.setText("PTVN");
        }
        else if(delta==0)
        {
            tvKQ.setText("PT co n kep x="+ ((double)-b/(2*a)));
        }
        else
        {
            double x1 = ((double) (-b+Math.sqrt(delta))/(2*a));
            double x2 = ((double) (-b-Math.sqrt(delta))/(2*a));
            tvKQ.setText("PT co 2 n: x1="+x1+"; va x2="+x2);
        }
    }
}
