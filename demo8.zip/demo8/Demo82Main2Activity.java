package com.example.mob103.demo8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mob103.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class Demo82Main2Activity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo82_main2);
        textView = findViewById(R.id.demo82Textview);
        new VNAsyncTask().execute("http://www.google.com");//goi ham
    }
    public class VNAsyncTask extends AsyncTask<String,Void,String>
    {
        //ham xu ly input
        @Override
        protected String doInBackground(String... strings) {
            StringBuilder stringBuilder = new StringBuilder();
            try {
                URL url = new URL(strings[0]);//lay duong dan
                InputStreamReader inputStreamReader
                        =new InputStreamReader(url.openConnection().getInputStream());
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String line="";
                while ((line=bufferedReader.readLine())!=null)//neu khong phai cuoi luong
                {
                    stringBuilder.append(line);//dua dong doc duoc vao StringBuilder
                }
                bufferedReader.close();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return stringBuilder.toString();
        }
        //ket qua tra ve dien thoai
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            textView.setText(String.valueOf(s));//tra ket qua ve cho client
        }
    }
}
