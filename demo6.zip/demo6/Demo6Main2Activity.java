package com.example.mob103.demo6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mob103.R;

import java.util.ArrayList;
import java.util.List;

public class Demo6Main2Activity extends AppCompatActivity {
    Button btnThem, btnSua,btnXoa,btnLoadData;
    EditText txtMa,txtTen,txtSoLuong;
    ListView listView;
    ProductDAO productDAO;
    ArrayAdapter<String> arrayAdapter;
    List<String> ds=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo6_main2);
        btnThem = findViewById(R.id.demo6BtnThem);
        btnSua = findViewById(R.id.demo6BtnSua);
        btnXoa = findViewById(R.id.demo6BtnXoa);
        btnLoadData = findViewById(R.id.demo6BtnLoadData);
        txtMa = findViewById(R.id.demo6txtMaSP);
        txtTen = findViewById(R.id.demo6txtTenSP);
        txtSoLuong  =findViewById(R.id.demo6txtSoLuong);
        listView  = findViewById(R.id.demo6Listview);
        productDAO = new ProductDAO(this);
        ds.clear();
        ds = productDAO.getAllSanPhamToString();
        arrayAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,ds);
        listView.setAdapter(arrayAdapter);
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SanPham s = new SanPham();
                s.setMasp(txtMa.getText().toString());//lay du lieu nguoi dung nhap dua vao ma
                s.setTensp(txtTen.getText().toString());//lay du lieu nguoi dung nhap dua vao ten
                //lay du lieu nguoi dung nhap dua vao so luong
                s.setSoLuongSP(Integer.parseInt(txtSoLuong.getText().toString()));
                int kq = productDAO.insertProduct(s);
                if(kq==-1)
                {
                    Toast.makeText(getApplicationContext(),"Insert that bai",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(getApplicationContext(),"Insert thanh cong",Toast.LENGTH_LONG).show();
                }
            }
        });
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int kq=productDAO.deleteProduct(txtMa.getText().toString());
                if(kq==-1)
                {
                    Toast.makeText(getApplicationContext(),"Xoa that bai",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(getApplicationContext(),"Xoa thanh cong",Toast.LENGTH_LONG).show();
                }
            }
        });
        btnLoadData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ds.clear();
                ds = productDAO.getAllSanPhamToString();
                arrayAdapter = new ArrayAdapter<>(Demo6Main2Activity.this,android.R.layout.simple_list_item_1,ds);
                listView.setAdapter(arrayAdapter);
            }
        });
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SanPham s = new SanPham();
                s.setMasp(txtMa.getText().toString());//lay du lieu nguoi dung nhap dua vao ma
                s.setTensp(txtTen.getText().toString());//lay du lieu nguoi dung nhap dua vao ten
                //lay du lieu nguoi dung nhap dua vao so luong
                s.setSoLuongSP(Integer.parseInt(txtSoLuong.getText().toString()));
                int kq = productDAO.updateProduct(s);
                if(kq==-1)
                {
                    Toast.makeText(getApplicationContext(),"Cap nhat that bai",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(getApplicationContext(),"Cap nhat thanh cong",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
