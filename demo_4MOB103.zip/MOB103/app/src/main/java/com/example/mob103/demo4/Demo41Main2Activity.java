package com.example.mob103.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.mob103.R;

public class Demo41Main2Activity extends AppCompatActivity {
    EditText txt1,txt2;
    Button button;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main3);
        txt1 = findViewById(R.id.demo41txt1);
        txt2 = findViewById(R.id.demo41txt2);
        button = findViewById(R.id.demo41Btn);
        intent = new Intent(Demo41Main2Activity.this,Demo41SecondMain2Activity.class);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1. Tao bundle
                Bundle bundle =new Bundle();
                //2. Lay du lieu nhap
                int a = Integer.parseInt(txt1.getText().toString());
                int b = Integer.parseInt(txt2.getText().toString());
                //3. Dua du lieu vao bundle
                bundle.putInt("so1",a);
                bundle.putInt("so2",b);
                //4. Dua bundle vao intent
                intent.putExtra("mybundle",bundle);
                //5.Vận chuyển dữ liệu qua activity khác
                startActivity(intent);

            }
        });
    }
}
