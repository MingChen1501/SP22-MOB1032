package com.example.mob103.demo5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.mob103.R;

import java.util.List;

public class CustomeAdapter extends ArrayAdapter<Product> {
    private Context context;
    private int resource;
    private List<Product> objects;
    private LayoutInflater inflater;
    public CustomeAdapter(Context context, int resource,List<Product> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);//dich vu tao layout
    }

    //Tao view + hien thi du lieu
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder = new ViewHolder();
        //1.Thiet lap view
        if(convertView==null)//chua co view thi tao view moi
        {
            convertView = inflater.inflate(R.layout.item_listview_demo5,null);//tao layout moi
            holder.tvImage =(TextView)convertView.findViewById(R.id.demo5tvImage);//anh xa thanh phan
            holder.tvName = (TextView)convertView.findViewById(R.id.demo5tvName);
            holder.tvPrice = (TextView)convertView.findViewById(R.id.demo5tvPrive);
            convertView.setTag(holder);//tao template de lan sau su dung
        }
        else //neu da co view thi lay view cu
        {
            holder = (ViewHolder)convertView.getTag();
        }
        //2. Khoi tao du lieu cho view
        Product product = objects.get(position);
        holder.tvImage.setText(product.getId());
        holder.tvName.setText(product.getName());
        holder.tvPrice.setText(String.valueOf(product.getPrice()));
        return convertView;
    }

    public class ViewHolder{
        TextView tvImage, tvName, tvPrice;
    }
}
