package com.example.mob103.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mob103.R;

import java.util.ArrayList;
import java.util.List;

public class Demo43Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo43_main2);
        listView = findViewById(R.id.demo43Listview);
        List<Contact> arrContacts = new ArrayList<>();
        arrContacts.add(new Contact(Color.RED,"Nguyen Van A","09999999"));
        arrContacts.add(new Contact(Color.BLUE,"Tran Van B","0912456789"));
        arrContacts.add(new Contact(Color.GREEN,"Vu Van C","b08888888"));
        arrContacts.add(new Contact(Color.RED,"Tran Thi D","021111111"));
        final CustomAdapter adapter = new CustomAdapter(this,R.layout.item_listview43,arrContacts);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Contact item = adapter.getItem(i);
                Toast.makeText(getApplicationContext(),item.getName(),Toast.LENGTH_LONG).show();
            }
        });
    }
}
