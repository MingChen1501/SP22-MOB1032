package com.example.mob103.demo6;

public class SanPham {
    protected String masp;
    protected String tensp;
    protected int soLuongSP;

    public SanPham(String masp, String tensp, int soLuongSP) {
        this.masp = masp;
        this.tensp = tensp;
        this.soLuongSP = soLuongSP;
    }

    public SanPham() {
    }

    public String getMasp() {
        return masp;
    }

    public void setMasp(String masp) {
        this.masp = masp;
    }

    public String getTensp() {
        return tensp;
    }

    public void setTensp(String tensp) {
        this.tensp = tensp;
    }

    public int getSoLuongSP() {
        return soLuongSP;
    }

    public void setSoLuongSP(int soLuongSP) {
        this.soLuongSP = soLuongSP;
    }
}
