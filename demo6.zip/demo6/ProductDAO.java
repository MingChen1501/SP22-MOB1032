package com.example.mob103.demo6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.mob103.demo5.Product;
import com.example.mob103.demo5.SQLiteHelper;

import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    private SQLiteDatabase db;
    private SQLiteHelper dbHelper;
    private Context context;
    public static final String SQL_TAO_BANG_PRODUCT =
            "create table sanpham( masp text primary key, tensp text, soLuongSP text)";
    public static final String TABLE_NAME = "sanpham";

    public ProductDAO(Context context)
    {
        this.context = context;
        dbHelper = new SQLiteHelper(context);//tao database
        db = dbHelper.getWritableDatabase();//cho phep ghi du lieu vao database
    }
    public int insertProduct(SanPham p)
    {
        ContentValues values = new ContentValues();
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("soLuongSP",String.valueOf(p.getSoLuongSP()));
        if(db.insert(TABLE_NAME,null,values)<0)
        {
            return -1;//insert khong thanh cong
        }
        return 1;//insert thanh cong
    }
    public int deleteProduct(String masp)
    {
        if(db.delete(TABLE_NAME,"masp=?",new String[]{masp})<0)
        {
            return -1;//xoa khong thanh cong
        }
        return 1;
    }
    public int updateProduct(SanPham s)
    {
        ContentValues values = new ContentValues();//noi chua du lieu
        values.put("masp",s.getMasp());//them ma vao noi chua du lieu
        values.put("tensp",s.getTensp());//them ten vao noi chua du lieu
        values.put("soLuongSP",s.getSoLuongSP());//them so luong vao noi chua du lieu
        //thuc hien cap nhat
        int kq = db.update(TABLE_NAME,values,"masp=?",new String[]{s.getMasp()});
        //kiem tra ket qua
        if(kq<=0)
        {
            return -1;//update that bai
        }
        return 1;//update thanh cong
    }
    //lay du lieu
    public List<SanPham> getAllSanPham()
    {
        List<SanPham> ls = new ArrayList<>();//tao 1 danh sach
        //tao con tro doc du lieu
        Cursor c = db.query(TABLE_NAME,null,null,null
        ,null,null,null,null);
        c.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (c.isAfterLast()==false)//neu khong phai ban ghi cuoi cung thi tiep tuc doc
        {
            SanPham s = new SanPham();//tao 1 doi tuong rong
            //them du lieu vao doi tuong
            s.setMasp(c.getString(0));//lay ma the loai
            s.setTensp(c.getString(1));//lay ten the loai
            s.setSoLuongSP(c.getInt(2));//lay so luong
            //them doi tuong vao danh sach
            ls.add(s);
            c.moveToNext();//di chuyen den ban ghi tiep theo de doc
        }
        c.close();//dong con tro
        return ls;

    }
    public List<String> getAllSanPhamToString()
    {
        List<String> ls = new ArrayList<>();//tao 1 danh sach
        //tao con tro doc du lieu
        Cursor c = db.query(TABLE_NAME,null,null,null
                ,null,null,null,null);
        c.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (c.isAfterLast()==false)//neu khong phai ban ghi cuoi cung thi tiep tuc doc
        {
            SanPham s = new SanPham();//tao 1 doi tuong rong
            //them du lieu vao doi tuong
            s.setMasp(c.getString(0));//lay ma the loai
            s.setTensp(c.getString(1));//lay ten the loai
            s.setSoLuongSP(c.getInt(2));//lay so luong
            //them doi tuong vao danh sach
            String chuoi = s.getMasp()+" - "+s.getTensp()+" - "+s.getSoLuongSP();
            ls.add(chuoi);
            c.moveToNext();//di chuyen den ban ghi tiep theo de doc
        }
        c.close();//dong con tro
        return ls;

    }

}
