package com.example.mob103.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.mob103.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Demo71Main2Activity extends AppCompatActivity {
    TextView tv;
    EditText txt;
    Button btnSave,btnRead;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo71_main2);
        tv = findViewById(R.id.demo71Tv);
        txt = findViewById(R.id.demo71Edt);
        btnSave  = findViewById(R.id.demo71Btn);
        btnRead = findViewById(R.id.demo71Btn2);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = txt.getText().toString();
                ghiDuLieu(s);
            }
        });
        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                docDulieu();
            }
        });
    }
    public void ghiDuLieu(String s)
    {
        //lay duong dan file
        String path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/data1.txt";
        try {
            //Tao luong ghi du lieu
            OutputStreamWriter streamWriter
                    =new OutputStreamWriter(new FileOutputStream(path));
            //ghi
            streamWriter.write(s);
            streamWriter.close();
            tv.setText("Ghi thanh cong");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            tv.setText(e.getMessage());//ghi thong bao loi
        } catch (IOException e) {
            e.printStackTrace();
            tv.setText(e.getMessage());//ghi thong bao loi
        }
    }
    public String docDulieu()
    {
        String dulieu="";
        //lay duong dan doc du lieu
        String path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/data1.txt";
        try {
            Scanner s = new Scanner(new File(path));//chuan bi file doc du lieu
            while (s.hasNext())//bat dau doc du lieu
            {
                dulieu=s.nextLine()+"\n";
            }
            tv.setText(String.valueOf(dulieu));
            s.close();//dong ket noi
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            tv.setText(e.getMessage());//dua ra thong bao doc that bai
        }
        return dulieu;
    }
}
